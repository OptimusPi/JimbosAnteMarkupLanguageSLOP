using Motely.Filters;

namespace Motely.Tests;

/// <summary>
/// A wrong key fails to load (never crashes) with a <c>JAML line N:</c> error that names the
/// offending key.
/// </summary>
public sealed class JamlKeyErrorTests
{
    private static string LoadError(string yaml)
    {
        Assert.False(JamlConfig.TryLoad(yaml, out _, out var error), "the filter loaded");
        return error!;
    }

    [Theory]
    [InlineData("name: x\nmust:\n  - joker: Blueprint\n    luckMoney: [0]\n", "luckMoney")]
    public void UnknownProperty_IsNamed(string yaml, string key)
    {
        var error = LoadError(yaml);
        Assert.StartsWith("JAML line ", error);
        Assert.Contains(key, error);
    }

    [Theory]
    [InlineData("must:\n  - score: 5\n    min: 1\n    luckMoney: [0]\n")]
    [InlineData("must:\n  - zzzzzz: 3\n")]
    [InlineData("{\"must\": [{\"type\": \"Joker\", \"value\": \"OopsAll6s\"}]}")]
    [InlineData("must:\n  - {}\n")]
    public void Clause_NeedsAKey(string yaml)
    {
        var error = LoadError(yaml);
        Assert.Contains("a clause needs a key", error);
    }

    [Fact]
    public void ClauseWrittenAsAList_IsAnError_NotACrash()
    {
        Assert.Contains("a clause needs a key", LoadError("must:\n  - [joker, Blueprint]\n"));
    }

    [Theory]
    [InlineData("should:\n  - and:\n    - smallBlindTag: NegativeTag\n      or:\n      - joker: Photograph\n      antes: [3]\n", "or")]
    [InlineData("must:\n  - rareJoker: Any\n    boosterPacks: [0]\n", "boosterPacks")]
    [InlineData("must:\n  - joker: Blueprint\n    antse: [1]\n", "antse")]
    [InlineData("must:\n  - joker: Blueprint\n    sources:\n      shopItem: [1]\n", "shopItem")]
    [InlineData("must:\n  - joker: Blueprint\n    shopItems: [1]\n", "shopItems")]
    [InlineData("nmae: x\n", "nmae")]
    public void UnknownKey_IsAnError_NamingIt(string yaml, string key)
    {
        var error = LoadError(yaml);
        Assert.StartsWith("JAML line ", error);
        Assert.Contains($"'{key}'", error);
    }

    [Fact]
    public void ASecondClauseKeyTheTypeTakes_IsNotTwoClauses()
    {
        // soulOrder takes boosterPacks as its own key.
        var config = ProofSearch.LoadOrThrow("must:\n  - soulOrder: [{ legendary: Perkeo }]\n    boosterPacks: [0, 1]\n");
        Assert.IsType<LegendarySoulOrderClause>(Assert.Single(config.Must));
    }
}
