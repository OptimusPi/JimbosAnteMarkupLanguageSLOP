using Motely.Filters;
using Motely.Gpu;

namespace Motely.Tests;

public sealed class GpuSearchTests
{
    [Theory]
    [InlineData(
        """
        name: VoucherParity
        deck: Red
        stake: White
        must:
          - voucher: Telescope
            antes: [1, 2]
        """,
        0,
        2
    )]
    [InlineData(
        """
        name: TagParity
        deck: Ghost
        stake: White
        must:
          - tag: NegativeTag
            antes: [1, 2]
        """,
        0,
        2
    )]
    [InlineData(
        """
        name: BossParity
        deck: Red
        stake: White
        must:
          - boss: TheEye
            antes: [3, 4]
        mustNot:
          - boss: TheHook
            antes: [1]
        """,
        0,
        2
    )]
    [InlineData(
        """
        name: SoulEditionParity
        deck: Ghost
        stake: White
        must:
          - legendaryJoker: Perkeo
            edition: Negative
            antes: [1, 2, 3, 4]
        should:
          - voucher: CrystalBall
            antes: [1, 2, 3]
            score: 5
        """,
        0,
        4
    )]
    [InlineData(
        """
        name: SoulPackParity
        deck: Red
        stake: White
        must:
          - spectralCard: TheSoul
            antes: [1]
            sources:
              boosterPacks: [0, 1]
        """,
        0,
        3
    )]
    [InlineData(
        """
        name: ErraticDeckAndLogicParity
        deck: Erratic
        stake: White
        must:
          - and:
              - erraticRank: Ace
                min: 8
              - erraticSuit: Spades
                min: 16
        """,
        0,
        2
    )]
    [InlineData(
        """
        name: ShopJokerParity
        deck: Red
        stake: White
        must:
          - rareJoker: []
            edition: Foil
            antes: [1, 2]
        """,
        0,
        4
    )]
    [InlineData(
        """
        name: BuffoonJokerParity
        deck: Red
        stake: White
        must:
          - uncommonJoker: []
            edition: Foil
            antes: [1, 2]
            sources:
              boosterPacks: [0, 1]
        """,
        0,
        4
    )]
    public async Task Gpu_and_Cpu_sequential_sweeps_produce_bit_exact_identical_matches_and_scores(
        string jaml,
        long startBatch,
        long endBatch
    )
    {
        var config = JamlConfig.FromJaml(jaml);
        Assert.True(GpuFilterProgram.Compile(config).HasSelectiveOps);

        var cpuMatches = await SweepAsync(config, startBatch, endBatch, useGpu: false);
        var gpuMatches = await SweepAsync(config, startBatch, endBatch, useGpu: true);

        Assert.NotEmpty(cpuMatches);
        Assert.Equal(cpuMatches, gpuMatches);
    }

    [Fact]
    public async Task Gpu_mixed_special_spectral_and_mustNot_voucher_roll1_have_zero_false_negatives()
    {
        string jaml = """
            name: MixedSpectralAndVoucherRoll1
            deck: Red
            stake: White
            must:
              - boss: TheEye
                antes: [3, 4]
              - spectralCard: [TheSoul, Immolate]
                antes: [1, 2]
            mustNot:
              - voucher: Hieroglyph
                antes: [1]
                rolls: [1]
            """;

        var config = JamlConfig.FromJaml(jaml);
        var cpuMatches = await SweepAsync(config, 0, 1, useGpu: false);
        var gpuMatches = await SweepAsync(config, 0, 1, useGpu: true);

        Assert.NotEmpty(cpuMatches);
        Assert.Equal(cpuMatches, gpuMatches);
    }

    [Fact]
    public async Task Gpu_OpTag_Ante1_all_24_tags_and_glitched_NaN_seeds_match_Cpu_bit_for_bit()
    {
        var disallowed = MotelySingleSearchContext.DisallowedAnteOneTags.ToHashSet();

        foreach (var tag in Enum.GetValues<MotelyTag>())
        {
            string jaml = $"""
                name: Ante1Tag_{tag}
                deck: Red
                stake: White
                must:
                  - tag: {tag}
                    antes: [1]
                    rolls: [0, 1]
                """;
            var config = JamlConfig.FromJaml(jaml);
            Assert.True(GpuFilterProgram.Compile(config).HasSelectiveOps);

            var cpu = await SweepAsync(config, 0, 1, useGpu: false);
            var gpu = await SweepAsync(config, 0, 1, useGpu: true);

            if (disallowed.Contains(tag))
                Assert.Empty(cpu);
            else
                Assert.NotEmpty(cpu);

            Assert.Equal(cpu, gpu);
        }

        // Pin exact sequential batches containing glitched NaN seeds S4DM5V37, S4TMWWAE (BossTag) and 1V3UQ6AP (CharmTag).
        foreach (var (seed, expectedTag) in new[]
        {
            ("S4DM5V37", MotelyTag.BossTag),
            ("S4TMWWAE", MotelyTag.BossTag),
            ("1V3UQ6AP", MotelyTag.CharmTag),
        })
        {
            long batchIdx = ComputeBatchIndex(seed, batchChars: 3);
            var config = JamlConfig.FromJaml($"""
                name: GlitchedTag_{seed}
                deck: Erratic
                stake: White
                must:
                  - tag: {expectedTag}
                    antes: [1]
                """);
            var cpu = await SweepAsync(config, batchIdx, batchIdx + 1, useGpu: false);
            var gpu = await SweepAsync(config, batchIdx, batchIdx + 1, useGpu: true);

            Assert.Contains(cpu, m => m.Seed == seed);
            Assert.Equal(cpu, gpu);
        }
    }

    [Fact]
    public async Task Gpu_Voucher_roll1_matches_Simd_and_Scalar_scoring_across_must_should_and_mustNot()
    {
        var mustCfg = JamlConfig.FromJaml("""
            name: VoucherRoll1Must
            deck: Red
            stake: White
            must:
              - voucher: [Telescope, Overstock, Grabber, Blank]
                antes: [1, 2]
                rolls: [1]
            """);
        var shouldCfg = JamlConfig.FromJaml("""
            name: VoucherRoll1Should
            deck: Red
            stake: White
            cutoff: 1
            should:
              - voucher: [Telescope, Overstock, Grabber, Blank]
                antes: [1, 2]
                rolls: [1]
                score: 1
            """);
        var mustNotCfg = JamlConfig.FromJaml("""
            name: VoucherRoll1MustNot
            deck: Red
            stake: White
            must:
              - boss: TheHook
                antes: [1]
            mustNot:
              - voucher: [Telescope, Overstock, Grabber, Blank]
                antes: [1, 2]
                rolls: [1]
            """);

        Assert.True(GpuFilterProgram.Compile(mustCfg).HasSelectiveOps);
        Assert.True(GpuFilterProgram.Compile(mustNotCfg).HasSelectiveOps);

        var simdMust = (await SweepAsync(mustCfg, 0, 1, useGpu: false)).Select(x => x.Seed).ToList();
        var gpuMust = (await SweepAsync(mustCfg, 0, 1, useGpu: true)).Select(x => x.Seed).ToList();
        var scalarShould = (await SweepAsync(shouldCfg, 0, 1, useGpu: false)).Where(x => x.Score >= 1).Select(x => x.Seed).ToList();

        Assert.NotEmpty(simdMust);
        Assert.Equal(simdMust, gpuMust);
        Assert.Equal(simdMust, scalarShould);

        var cpuMustNot = await SweepAsync(mustNotCfg, 0, 1, useGpu: false);
        var gpuMustNot = await SweepAsync(mustNotCfg, 0, 1, useGpu: true);
        Assert.NotEmpty(cpuMustNot);
        Assert.Equal(cpuMustNot, gpuMustNot);
    }

    [Fact]
    public async Task Gpu_JokerClause_legendary_or_any_and_zero_min_Soul_clauses_have_zero_false_negatives()
    {
        var legendaryViaJokerKey = JamlConfig.FromJaml("""
            name: PerkeoViaJokerKey
            deck: Red
            stake: White
            must:
              - joker: Perkeo
                antes: [1]
            """);
        Assert.False(GpuFilterProgram.Compile(legendaryViaJokerKey).HasSelectiveOps);

        var anyJokerNegative = JamlConfig.FromJaml("""
            name: AnyJokerNegative
            deck: Red
            stake: White
            must:
              - joker: []
                edition: Negative
                antes: [1]
            """);
        Assert.False(GpuFilterProgram.Compile(anyJokerNegative).HasSelectiveOps);

        var zeroMinSoul = new JamlConfig
        {
            Name = "ZeroMinSoulAndBoss",
            Deck = MotelyDeck.Red,
            Stake = MotelyStake.White,
        };
        zeroMinSoul.Must.Add(new BossClause { Bosses = [MotelyBossBlind.TheHook], Antes = [1] });
        zeroMinSoul.Must.Add(new LegendaryJokerClause { Jokers = [MotelyJoker.Perkeo], Antes = [1], Min = 0, Max = 0 });
        zeroMinSoul.Must.Add(new SpectralCardClause { Spectrals = [MotelySpectralCard.TheSoul], Antes = [1], Min = 0, Max = 0 });

        var cpu = await SweepAsync(zeroMinSoul, 0, 1, useGpu: false);
        var gpu = await SweepAsync(zeroMinSoul, 0, 1, useGpu: true);
        Assert.NotEmpty(cpu);
        Assert.Equal(cpu, gpu);
    }

    private static long ComputeBatchIndex(string seed, int batchChars)
    {
        long batchIdx = 0;
        long mult = 1;
        for (int p = batchChars; p < 8; p++)
        {
            int d = Array.IndexOf(MotelyGlobals.SeedDigits, seed[p]);
            Assert.True(d >= 0, $"Invalid digit '{seed[p]}' in seed '{seed}'");
            batchIdx += d * mult;
            mult *= 35L;
        }
        return batchIdx;
    }

    private static async Task<List<(string Seed, int Score)>> SweepAsync(
        JamlConfig config,
        long startBatch,
        long endBatch,
        bool useGpu
    )
    {
        var plan = MotelySearchBuilder.CreatePlan(config, int.MinValue);
        var found = new List<(string Seed, int Score)>();

        var settings = plan
            .Settings.WithSourceConfig(config)
            .WithThreadCount(Environment.ProcessorCount)
            .WithBatchCharacterCount(3)
            .WithSequentialSearch()
            .WithStartBatchIndex(startBatch)
            .WithEndBatchIndex(endBatch)
            .WithAutoScoreCutoff(false)
            .WithGpuSearch(useGpu)
            .WithQuietMode(true);

        if (settings.SeedScoreDesc is not null)
        {
            settings = settings.WithScoredResultCallback(r =>
            {
                lock (found)
                {
                    found.Add((r.Seed, r.Score));
                }
            });
        }
        else
        {
            settings = settings.WithSeedMatchCallback(s =>
            {
                lock (found)
                {
                    found.Add((s, 0));
                }
            });
        }

        using var search = settings.Start();
        await search.WaitForCompletionAsync();

        found.Sort((a, b) =>
        {
            int cmp = string.CompareOrdinal(a.Seed, b.Seed);
            return cmp != 0 ? cmp : a.Score.CompareTo(b.Score);
        });
        return found;
    }
}
