using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Motely.Filters;
using Motely.Gpu;
using Xunit;

namespace Motely.Tests;

/// <summary>GPU search fallback (GpuSeedSearcher, GpuDeviceInfo).</summary>
public sealed class GpuFallbackTests
{
    [Fact]
    public void GpuDeviceInfo_and_Benchmark_execute_safely()
    {
        var devices = GpuDeviceInfo.DiscoverDevices();
        Assert.NotNull(devices);

        var bestDevice = GpuDeviceInfo.GetBestDevice();
        if (bestDevice is not null && bestDevice.SupportsFp64)
        {
            Assert.True(bestDevice.ComputeUnits > 0);
            Assert.True(bestDevice.GlobalMemoryBytes > 0);

            var benchResult = GpuSeedSearcher.Benchmark(batchChars: 3, batchCount: 4);
            Assert.True(benchResult.GpuAvailable);
            Assert.Equal(4L * 42_875L, benchResult.SeedsEvaluated);
            Assert.True(benchResult.MillionsOfSeedsPerSecond >= 0);
        }
        else
        {
            var benchResult = GpuSeedSearcher.Benchmark(batchChars: 3, batchCount: 4);
            Assert.False(benchResult.GpuAvailable);
            Assert.Equal(0, benchResult.SeedsEvaluated);
        }
    }

    [Fact]
    public void GpuFilterProgram_handles_null_empty_and_unsupported_clauses_cleanly()
    {
        var emptyFromNull = GpuFilterProgram.Compile(null);
        Assert.NotNull(emptyFromNull);
        Assert.False(emptyFromNull.HasSelectiveOps);
        Assert.Equal(0, emptyFromNull.InstructionGroupCount);

        var emptyFromEmptyConfig = GpuFilterProgram.Compile(new JamlConfig());
        Assert.NotNull(emptyFromEmptyConfig);
        Assert.False(emptyFromEmptyConfig.HasSelectiveOps);
        Assert.Equal(0, emptyFromEmptyConfig.InstructionGroupCount);

        // Unsupported or non-selective clauses should compile with 0 selective GPU ops
        var unsupportedConfig = new JamlConfig
        {
            Must =
            [
                new PokerHandClause { PokerHands = [MotelyPokerHand.Flush] }
            ]
        };
        var unsupportedProgram = GpuFilterProgram.Compile(unsupportedConfig);
        Assert.NotNull(unsupportedProgram);
        Assert.False(unsupportedProgram.HasSelectiveOps);
    }

    [Theory]
    [InlineData(0L, 0, 3)]
    [InlineData(42L, 100, 3)]
    [InlineData(35L * 35L, 34, 3)]
    [InlineData(12345L, 1000, 4)]
    public void ReconstructSeed_matches_digit_layout(long batchIdx, int intraBatchIdx, int batchChars)
    {
        Span<char> dest = stackalloc char[8];
        GpuSeedSearcher.ReconstructSeed(batchIdx, intraBatchIdx, batchChars, dest);
        Assert.Equal(8, dest.Length);
        Assert.All(dest.ToArray(), c => Assert.Contains(c, (IEnumerable<char>)MotelyGlobals.SeedDigits));
    }

    [Fact]
    public async Task Search_cleanly_falls_back_to_SIMD_CPU_when_Gpu_is_disabled_or_unsupported()
    {
        // Jaml with selective ops (Voucher: Hieroglyph in ante 1)
        string jaml = """
            name: HieroglyphTest
            deck: Red
            stake: White
            must:
              - voucher: Hieroglyph
                antes: [1]
            """;
        var config = JamlConfig.FromJaml(jaml);

        // Run with SIMD CPU (useGpu = false)
        var cpuMatches = await RunSearchSweepAsync(config, startBatch: 0, endBatch: 1, useGpu: false);

        // Run with GPU (useGpu = true)
        var gpuMatches = await RunSearchSweepAsync(config, startBatch: 0, endBatch: 1, useGpu: true);

        Assert.NotEmpty(cpuMatches);
        Assert.Equal(cpuMatches, gpuMatches);

        // Now test Jaml with NO selective ops (TarotCardClause is evaluated by CPU engine only)
        // With useGpu = true, HasSelectiveOps is false, so it MUST fall back cleanly to CPU SIMD
        string jamlNoGpu = """
            name: NoGpuOps
            deck: Red
            stake: White
            must:
              - tarotCard: TheFool
                antes: [1]
            """;
        var configNoGpu = JamlConfig.FromJaml(jamlNoGpu);
        Assert.False(GpuFilterProgram.Compile(configNoGpu).HasSelectiveOps);

        var cpuNoGpuMatches = await RunSearchSweepAsync(configNoGpu, startBatch: 0, endBatch: 1, useGpu: false);
        var gpuFallbackMatches = await RunSearchSweepAsync(configNoGpu, startBatch: 0, endBatch: 1, useGpu: true);

        Assert.NotEmpty(cpuNoGpuMatches);
        Assert.Equal(cpuNoGpuMatches, gpuFallbackMatches);
    }

    private static async Task<List<string>> RunSearchSweepAsync(
        JamlConfig config,
        long startBatch,
        long endBatch,
        bool useGpu
    )
    {
        var plan = MotelySearchBuilder.CreatePlan(config, int.MinValue);
        var found = new List<string>();

        var settings = plan
            .Settings.WithSourceConfig(config)
            .WithThreadCount(Environment.ProcessorCount)
            .WithBatchCharacterCount(3)
            .WithSequentialSearch()
            .WithStartBatchIndex(startBatch)
            .WithEndBatchIndex(endBatch)
            .WithAutoScoreCutoff(false)
            .WithGpuSearch(useGpu)
            .WithQuietMode(true);

        if (settings.SeedScoreDesc is not null)
        {
            settings = settings.WithScoredResultCallback(r =>
            {
                lock (found) { found.Add(r.Seed); }
            });
        }
        else
        {
            settings = settings.WithSeedMatchCallback(s =>
            {
                lock (found) { found.Add(s); }
            });
        }

        using var search = settings.Start();
        await search.WaitForCompletionAsync();

        found.Sort(StringComparer.Ordinal);
        return found;
    }
}
