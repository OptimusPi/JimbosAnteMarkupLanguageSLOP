using Motely.Filters;
using Motely.Gpu;
using Xunit;

namespace Motely.Tests;

public sealed class ChallengerEngineParityTests
{
    [Theory]
    [InlineData("Foil")]
    [InlineData("Holographic")]
    [InlineData("Polychrome")]
    [InlineData("Negative")]
    public async Task ShopJoker_all_editions_have_bit_exact_gpu_cpu_parity(string edition)
    {
        string jaml = $"""
            name: ShopJoker_{edition}
            deck: Red
            stake: White
            must:
              - rareJoker: []
                edition: {edition}
                antes: [1, 2]
            """;

        var config = JamlConfig.FromJaml(jaml);
        Assert.True(GpuFilterProgram.Compile(config).HasSelectiveOps);

        var cpuMatches = await SweepAsync(config, 0, 8, useGpu: false);
        var gpuMatches = await SweepAsync(config, 0, 8, useGpu: true);

        // Bit-exact match check: every seed found on CPU must match GPU and vice-versa
        Assert.Equal(cpuMatches, gpuMatches);
    }

    [Theory]
    [InlineData("Common")]
    [InlineData("Uncommon")]
    [InlineData("Rare")]
    public async Task ShopJoker_all_rarities_have_bit_exact_gpu_cpu_parity(string rarity)
    {
        string tag = rarity switch
        {
            "Common" => "commonJoker",
            "Uncommon" => "uncommonJoker",
            "Rare" => "rareJoker",
            _ => throw new ArgumentOutOfRangeException(nameof(rarity))
        };

        string jaml = $"""
            name: ShopJokerRarity_{rarity}
            deck: Red
            stake: White
            must:
              - {tag}: []
                edition: Foil
                antes: [1]
            """;

        var config = JamlConfig.FromJaml(jaml);
        Assert.True(GpuFilterProgram.Compile(config).HasSelectiveOps);

        var cpuMatches = await SweepAsync(config, 0, 4, useGpu: false);
        var gpuMatches = await SweepAsync(config, 0, 4, useGpu: true);

        Assert.NotEmpty(cpuMatches);
        Assert.Equal(cpuMatches, gpuMatches);
    }

    [Theory]
    [InlineData("Foil")]
    [InlineData("Holographic")]
    [InlineData("Polychrome")]
    [InlineData("Negative")]
    public async Task BuffoonJoker_all_editions_have_bit_exact_gpu_cpu_parity(string edition)
    {
        string jaml = $"""
            name: BuffoonJoker_{edition}
            deck: Red
            stake: White
            must:
              - uncommonJoker: []
                edition: {edition}
                antes: [1, 2]
                sources:
                  boosterPacks: [0, 1]
            """;

        var config = JamlConfig.FromJaml(jaml);
        Assert.True(GpuFilterProgram.Compile(config).HasSelectiveOps);

        var cpuMatches = await SweepAsync(config, 0, 8, useGpu: false);
        var gpuMatches = await SweepAsync(config, 0, 8, useGpu: true);

        Assert.Equal(cpuMatches, gpuMatches);
    }

    [Fact]
    public async Task High_ante_numbers_ante8_sweep_bit_exact_parity()
    {
        string jaml = """
            name: ShopJoker_Ante8
            deck: Red
            stake: White
            must:
              - uncommonJoker: []
                edition: Foil
                antes: [8]
            """;

        var config = JamlConfig.FromJaml(jaml);
        var program = GpuFilterProgram.Compile(config);
        Assert.True(program.HasSelectiveOps, "Expected Ante 8 to compile into GPU opcode");

        var cpuMatches = await SweepAsync(config, 0, 4, useGpu: false);
        var gpuMatches = await SweepAsync(config, 0, 4, useGpu: true);

        Assert.Equal(cpuMatches, gpuMatches);
    }

    [Theory]
    [InlineData(12)]
    [InlineData(16)]
    public async Task High_ante_numbers_ante12_and_16_behavior_investigation(int ante)
    {
        string jaml = $"""
            name: ShopJoker_Ante{ante}
            deck: Red
            stake: White
            must:
              - rareJoker: []
                edition: Foil
                antes: [{ante}]
            """;

        var config = JamlConfig.FromJaml(jaml);
        var program = GpuFilterProgram.Compile(config);

        // Compiler safely returns false for ante > 8 in TryEmitJokerStream, cleanly falling back to CPU
        Assert.False(program.HasSelectiveOps, $"Expected ante {ante} to fall back to CPU");

        // Verify that sweep produces bit-exact identical matches regardless
        var cpuMatches = await SweepAsync(config, 0, 2, useGpu: false);
        var gpuMatches = await SweepAsync(config, 0, 2, useGpu: true);

        Assert.Equal(cpuMatches, gpuMatches);
    }

    [Fact]
    public async Task Direct_Empirical_Verification_zero_false_negatives_shop_and_buffoon()
    {
        // Construct a filter with both Shop and Buffoon Jokers across multiple antes
        string jaml = """
            name: DirectZeroFalseNegativeCheck
            deck: Red
            stake: White
            must:
              - rareJoker: []
                edition: Foil
                antes: [1, 2]
            """;

        var config = JamlConfig.FromJaml(jaml);
        var program = GpuFilterProgram.Compile(config);
        Assert.True(program.HasSelectiveOps);

        // Run full CPU search over 16 batches (686,000 seeds)
        var cpuMatches = await SweepAsync(config, 0, 16, useGpu: false);
        Assert.NotEmpty(cpuMatches);

        // Run GPU search over the exact same 16 batches
        var gpuMatches = await SweepAsync(config, 0, 16, useGpu: true);

        // Check for ANY false negatives: Every single CPU match MUST be found by GPU search!
        var cpuSeedSet = new HashSet<string>(cpuMatches.Select(m => m.Seed));
        var gpuSeedSet = new HashSet<string>(gpuMatches.Select(m => m.Seed));

        var missingInGpu = cpuSeedSet.Except(gpuSeedSet).ToList();
        Assert.Empty(missingInGpu);

        // Check for false positives: Every GPU match must be valid on CPU
        var extraInGpu = gpuSeedSet.Except(cpuSeedSet).ToList();
        Assert.Empty(extraInGpu);

        // Scores must match bit-exactly
        Assert.Equal(cpuMatches, gpuMatches);
    }

    private static async Task<List<(string Seed, int Score)>> SweepAsync(
        JamlConfig config,
        long startBatch,
        long endBatch,
        bool useGpu
    )
    {
        var plan = MotelySearchBuilder.CreatePlan(config, int.MinValue);
        var found = new List<(string Seed, int Score)>();

        var settings = plan
            .Settings.WithSourceConfig(config)
            .WithThreadCount(Environment.ProcessorCount)
            .WithBatchCharacterCount(3)
            .WithSequentialSearch()
            .WithStartBatchIndex(startBatch)
            .WithEndBatchIndex(endBatch)
            .WithAutoScoreCutoff(false)
            .WithGpuSearch(useGpu)
            .WithQuietMode(true);

        if (settings.SeedScoreDesc is not null)
        {
            settings = settings.WithScoredResultCallback(r =>
            {
                lock (found)
                {
                    found.Add((r.Seed, r.Score));
                }
            });
        }
        else
        {
            settings = settings.WithSeedMatchCallback(s =>
            {
                lock (found)
                {
                    found.Add((s, 0));
                }
            });
        }

        using var search = settings.Start();
        await search.WaitForCompletionAsync();

        found.Sort((a, b) =>
        {
            int cmp = string.CompareOrdinal(a.Seed, b.Seed);
            return cmp != 0 ? cmp : a.Score.CompareTo(b.Score);
        });
        return found;
    }
}
