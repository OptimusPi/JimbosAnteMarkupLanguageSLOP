using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.Intrinsics;

namespace Motely.Filters;

[YamlDotNet.Serialization.YamlSerializable]
public sealed partial class PlanetCardClause: IMotelyClause, IAnteScopedClause
{
    public MotelyPlanetCard[]? PlanetCard { get => Planets; set => Planets = value ?? []; }
    public MotelyPlanetCard[]? PlanetCards { get => Planets; set => Planets = value ?? []; }

    /// <summary><c>ante: 2</c> or <c>ante: [1, 2]</c> is <c>antes:</c>.</summary>
    public int[]? Ante { get => null; set => Antes = value ?? Antes; }

    public string? Label { get; set; }
    public int Min { get; set; } = 1;
    public int? Max { get; set; }
    public int Score { get; set; } = 1;
    public int[] Antes { get; set; } = [1, 2, 3, 4, 5, 6, 7, 8];
    public MotelyPlanetCard[] Planets { get; set; } = [];

    // null = no sources: in JAML → filter DefaultSources at CreateFilter/score (not parse).
    // applies. Any explicit block (even partial) is used verbatim — defaults never merge in.
    public PlanetSourceConfig? Sources { get; set; }

    public IMotelySeedFilterDesc CreateFilterDesc() => new PlanetCardFilterDesc(this);
}

public struct PlanetCardFilterDesc(PlanetCardClause clause)
    : IMotelySeedFilterDesc<PlanetCardFilterDesc.PlanetCardFilter>
{
    private readonly PlanetCardClause _clause = clause;

    /// <summary>
    /// Filter-layer default when Sources is null. Shop only; packs need explicit sources:.
    /// </summary>
    internal static readonly PlanetSourceConfig DefaultSources = new()
    {
        ShopItems = [0, 1, 2, 3, 4, 5, 6, 7],
    };

    public PlanetCardFilter CreateFilter(ref MotelyFilterCreationContext ctx)
    {
        var sources = _clause.Sources ?? DefaultSources;

        foreach (var ante in _clause.Antes)
        {
            ctx.CacheShopStream(ante);
            ctx.CacheBoosterPackStream(ante);
        }

        int maxShopItem = 0;
        for (int i = 0; i < sources.ShopItems.Length; i++)
        {
            if (sources.ShopItems[i] > maxShopItem)
                maxShopItem = sources.ShopItems[i];
        }

        int maxBoosterPack = 0;
        for (int i = 0; i < sources.BoosterPacks.Length; i++)
        {
            if (sources.BoosterPacks[i] > maxBoosterPack)
                maxBoosterPack = sources.BoosterPacks[i];
        }

        return new PlanetCardFilter(_clause, maxShopItem, maxBoosterPack);
    }

    public struct PlanetCardFilter(PlanetCardClause clause, int maxShopItem, int maxBoosterPack)
        : IMotelySeedFilter
    {
        private readonly PlanetCardClause _clause = clause;
        private readonly int _maxShopItem = maxShopItem;
        private readonly int _maxBoosterPack = maxBoosterPack;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public VectorMask Filter(ref MotelyVectorSearchContext ctx)
        {
            // empty Planets = category any
            var clause = _clause;
            int maxShopItem = _maxShopItem;
            int maxBoosterPack = _maxBoosterPack;
            int needed = clause.Min;
            Debug.Assert(needed > 0, "PlanetCardClause.Min must be > 0 — loader bug.");

            Vector256<int> matchCounts = Vector256<int>.Zero;
            var sources = clause.Sources ?? DefaultSources;
            var shopIndices = sources.ShopItems;
            var boosterPacks = sources.BoosterPacks;

            VectorMask ante1Extended = VectorMask.NoBitsSet;
            if (boosterPacks.Length > 0 && SimdPackSupport.NeedsAnte1Extension(maxBoosterPack))
            {
                bool hasAnte1 = false;
                for (int i = 0; i < clause.Antes.Length; i++)
                    if (clause.Antes[i] == 1)
                    {
                        hasAnte1 = true;
                        break;
                    }
                if (hasAnte1)
                    ante1Extended = SimdPackSupport.Ante1PackExtensionMask(ref ctx);
            }

            foreach (var ante in clause.Antes)
            {
                // ── Shop items SIMD ──
                if (shopIndices.Length > 0)
                {
                    var shopStream = ctx.CreateShopItemStream(ante);

                    for (int slot = 0; slot <= maxShopItem; slot++)
                    {
                        var item = ctx.GetNextShopItem(ref shopStream);
                        bool isTarget = false;
                        for (int i = 0; i < shopIndices.Length; i++)
                        {
                            if (shopIndices[i] == slot)
                            {
                                isTarget = true;
                                break;
                            }
                        }

                        if (!isTarget)
                            continue;

                        VectorMask isPlanet = VectorEnum256.Equals(
                            item.TypeCategory,
                            MotelyItemTypeCategory.PlanetCard
                        );
                        VectorMask match = MatchPlanets(item, clause) & isPlanet;

                        if (match.IsPartiallyTrue())
                        {
                            matchCounts = Vector256.Add(
                                matchCounts,
                                Vector256.ConditionalSelect(
                                    MotelyVectorUtils.VectorMaskToConditionalSelectMask(match),
                                    Vector256.Create(1),
                                    Vector256<int>.Zero
                                )
                            );
                        }
                    }
                }

                // ── Celestial packs SIMD ──
                // Per-lane size (Normal=3, Jumbo/Mega=5) + ante-1 slot reachability.
                if (boosterPacks.Length > 0)
                {
                    var packStream = ctx.CreateBoosterPackStream(ante);
                    var planetStream = ctx.CreateCelestialPackPlanetStream(ante);

                    for (int p = 0; p <= maxBoosterPack; p++)
                    {
                        var pack = ctx.GetNextBoosterPack(ref packStream);
                        bool isTarget = false;
                        for (int i = 0; i < boosterPacks.Length; i++)
                        {
                            if (boosterPacks[i] == p)
                            {
                                isTarget = true;
                                break;
                            }
                        }

                        VectorMask reachable = SimdPackSupport.SlotReachableMask(
                            ante,
                            p,
                            ante1Extended
                        );
                        VectorMask countLanes = isTarget
                            ? reachable
                            : VectorMask.NoBitsSet;

                        var packType = pack.GetPackType();
                        VectorMask isCelestial = VectorEnum256.Equals(
                            packType,
                            MotelyBoosterPackType.Celestial
                        );
                        if (isCelestial.IsAllFalse())
                            continue;

                        if (sources.RequireMegaPack)
                        {
                            countLanes &= VectorEnum256.Equals(
                                pack.GetPackSize(),
                                MotelyBoosterPackSize.Mega
                            );
                        }

                        VectorMask isNormal = VectorEnum256.Equals(
                            pack.GetPackSize(),
                            MotelyBoosterPackSize.Normal
                        );
                        VectorMask baseLanes = isCelestial;
                        VectorMask extraLanes = isCelestial & ~isNormal;
                        var baseMask = SimdPackSupport.ToPrngMask(baseLanes);
                        var extraMask = SimdPackSupport.ToPrngMask(extraLanes);
                        // Deduplicated against this pack, as the scalar pack contents are: a raw
                        // draw keeps the repeat the scalar engine resamples (often into a target).
                        MotelyVectorItemSet packItems = new();

                        for (int c = 0; c < 3; c++)
                        {
                            var card = ctx.GetNextPlanet(ref planetStream, in packItems, baseMask);
                            packItems.Append(card);
                            if (countLanes.IsPartiallyTrue())
                                SimdPackSupport.AddMatchCounts(
                                    MatchPlanets(card, clause) & countLanes & baseLanes,
                                    ref matchCounts
                                );
                        }

                        if (extraLanes.IsPartiallyTrue())
                        {
                            for (int c = 0; c < 2; c++)
                            {
                                var card = ctx.GetNextPlanet(ref planetStream, in packItems, extraMask);
                                packItems.Append(card);
                                if (countLanes.IsPartiallyTrue())
                                    SimdPackSupport.AddMatchCounts(
                                        MatchPlanets(card, clause) & countLanes & extraLanes,
                                        ref matchCounts
                                    );
                            }
                        }
                    }
                }
            }

            return SimdPackSupport.MeetsMinMaxMask(matchCounts, needed, clause.Max);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static VectorMask MatchPlanets(MotelyItemVector items, PlanetCardClause clause)
        {
            var planets = clause.Planets;
            if ((planets.Length == 0))
                return VectorEnum256.Equals(items.TypeCategory, MotelyItemTypeCategory.PlanetCard);

            VectorMask mask = VectorMask.NoBitsSet;
            var itemTypes = items.Type;

            for (int i = 0; i < planets.Length; i++)
            {
                var targetType = (int)MotelyItemTypeCategory.PlanetCard | (int)planets[i];
                mask |= VectorEnum256.Equals(itemTypes, (MotelyItemType)targetType);
            }

            return mask;
        }
    }
}

/// <summary>
/// <c>sources:</c> block for <c>planetCard:</c>. Colocated with <see cref="PlanetCardFilterDesc"/> (T5).
/// </summary>
[YamlDotNet.Serialization.YamlSerializable]
public sealed partial record PlanetSourceConfig
{
    /// <summary><c>requireMega:</c> is <c>requireMegaPack:</c>.</summary>
    public bool? RequireMega { get => null; set => RequireMegaPack = value ?? RequireMegaPack; }

    public int[] ShopItems { get; set; } = [];
    public int[] BoosterPacks { get; set; } = [];

    /// <summary>When true, only Mega-sized Celestial packs count (Normal/Jumbo still advance the stream).</summary>
    public bool RequireMegaPack { get; set; }
}
