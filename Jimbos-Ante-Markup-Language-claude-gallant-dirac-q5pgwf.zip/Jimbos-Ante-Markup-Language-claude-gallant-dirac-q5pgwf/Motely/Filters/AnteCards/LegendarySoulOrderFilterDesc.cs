using System.Diagnostics;
using System.Runtime.CompilerServices;
using Motely;

namespace Motely.Filters;

/// <summary>
/// <c>soulOrder:</c> — the run-wide order the Souls a run opens turn into legendaries (E17).
///
/// Balatro keys the legendary pool <c>Joker4</c> with no ante, so the Nth Soul the player opens in
/// the whole run gets draw N, whatever ante it sits in. <see cref="Entries"/> is that ordered list:
/// entry <c>i</c> is the (i+1)-th Soul opened. Each entry may pin an ante range (<c>antes:</c>, empty
/// = any ante). The clause matches only when every listed Soul lands on its legendary in order.
///
/// A legendary already opened (or listed in <c>with: { jokers: [...] }</c>) is owned, so the game
/// resamples (<c>Joker4_resample2</c>, …) rather than giving a duplicate — unless <c>with:</c> holds
/// Showman, which keeps duplicates in the pool. With Showman held the effective sequence is the raw
/// <c>Joker4</c> draws (the same sequence <c>jamlyze_seeds</c> reports).
/// </summary>
[YamlDotNet.Serialization.YamlSerializable]
public sealed partial class LegendarySoulOrderClause: IMotelyClause, IWithScopedClause
{
    public SoulOrderEntry[]? SoulOrder
    {
        get => Entries;
        set => Entries = RequireSoulOrder(value);
    }

    public SoulOrderEntry[]? SoulOrders
    {
        get => Entries;
        set => Entries = RequireSoulOrder(value);
    }

    // The plain-loader rewrite dropped JamlValidator, whose CheckSoulOrder rejected a soulOrder
    // list that can never match; keep that guard at the binding point, where the JAML value lands.
    private static SoulOrderEntry[] RequireSoulOrder(SoulOrderEntry[]? entries)
    {
        entries ??= [];
        if (entries.Length == 0)
            throw new InvalidOperationException("soulOrder needs at least one soul.");

        for (int i = 0; i < entries.Length; i++)
        {
            var legendary = entries[i].Legendary;
            if (
                ((MotelyJokerRarity)((int)legendary & MotelyGlobals.JokerRarityMask))
                != MotelyJokerRarity.Legendary
            )
                throw new InvalidOperationException(
                    $"soulOrder[{i}] names {legendary}, which is not a legendary."
                );
        }

        return entries;
    }

    public string? Label { get; set; }
    public int Min { get; set; } = 1;
    public int? Max { get; set; }
    public int Score { get; set; } = 1;

    /// <summary>The ordered Souls: entry <c>i</c> is the (i+1)-th Soul the run opens.</summary>
    public SoulOrderEntry[] Entries { get; set; } = [];

    /// <summary>How far the walk runs. Antes past this are ignored.</summary>
    public int MaxAnte { get; set; } = 8;

    /// <summary>Booster-pack slots the walk reads Souls from. Empty = <c>[0..5]</c>.</summary>
    public int[] BoosterPacks { get; set; } = [];

    /// <summary>
    /// Jokers held while opening Souls (<c>with: { jokers: [Showman] }</c>). A held legendary drops
    /// out of the pool and resamples; holding Showman keeps duplicates in, so the sequence becomes
    /// the raw <c>Joker4</c> draws.
    /// </summary>
    public MotelyWith With { get; set; } = new();

    public IMotelySeedFilterDesc CreateFilterDesc() => new LegendarySoulOrderFilterDesc(this);
}

/// <summary>One Soul in a <c>soulOrder:</c> list: the legendary it must give, and the antes it may sit in.</summary>
[YamlDotNet.Serialization.YamlSerializable]
public sealed partial record SoulOrderEntry
{
    public MotelyJoker Legendary { get; set; }

    /// <summary>Antes this Soul may be opened in. Empty = any ante from 1 up to the clause's
    /// <c>maxAnte</c>; ante 0, in the run only after Hieroglyph or Petroglyph, only when an entry names it.</summary>
    public int[] Antes { get; set; } = [];
}

public struct LegendarySoulOrderFilterDesc(LegendarySoulOrderClause clause)
    : IMotelySeedFilterDesc<LegendarySoulOrderFilterDesc.LegendarySoulOrderFilter>
{
    private readonly LegendarySoulOrderClause _clause = clause;

    public LegendarySoulOrderFilter CreateFilter(ref MotelyFilterCreationContext ctx)
    {
        int maxAnte = _clause.MaxAnte > 0 ? _clause.MaxAnte : 8;
        for (int ante = 0; ante <= maxAnte; ante++)
            ctx.CacheBoosterPackStream(ante, force: true);
        return new LegendarySoulOrderFilter(_clause);
    }

    public struct LegendarySoulOrderFilter(LegendarySoulOrderClause clause) : IMotelySeedFilter
    {
        private readonly LegendarySoulOrderClause _clause = clause;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public VectorMask Filter(ref MotelyVectorSearchContext ctx)
        {
            Debug.Assert(_clause.Min > 0, "LegendarySoulOrderClause.Min must be > 0 — loader bug.");

            // Rough cut only: the run-wide Soul walk is order-dependent (it threads one Joker4
            // stream across antes), so it cannot be a pure SIMD lane mask. Keep every valid lane
            // and let the scalar scoring pass confirm (IsExactFilterConfirm = false).
            uint laneMask = 0;
            for (int lane = 0; lane < MotelyGlobals.MaxVectorWidth; lane++)
                if (ctx.IsLaneValid(lane))
                    laneMask |= 1u << lane;

            return new VectorMask(laneMask);
        }
    }
}
