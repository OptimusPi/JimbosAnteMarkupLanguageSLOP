using System;
using System.Linq;

namespace Motely.Filters;

public sealed class JamlSearchPlan
{
    public IMotelySearchSettings Settings { get; set; } = null!;
    public int ScoreTallyColumnCount { get; set; }
    public IReadOnlyList<string> TallyLabels { get; set; } = [];
}

public static class MotelySearchBuilder
{
    /// <inheritdoc cref="CreateSettings"/>
    public static JamlSearchPlan CreatePlan(JamlConfig config, int? engineCutoff = null)
    {
        var settings = CreateSettings(config, engineCutoff);
        return new JamlSearchPlan
        {
            Settings = settings,
            ScoreTallyColumnCount = config.Should.Count,
            TallyLabels = [.. config.Should.Select(DefaultTallyLabel)],
        };
    }

    /// <summary>
    /// The tally-column label for a should clause: the author's explicit label when given,
    /// otherwise "score{index}".
    /// </summary>
    public static string DefaultTallyLabel(IMotelyClause clause, int index) =>
        clause.Label ?? $"score{index}";

    /// <summary>
    /// The engine's search settings for a filter: its deck and stake, its must and exact mustNot
    /// clauses as the SIMD chain, and the scoring pass when anything scores.
    /// </summary>
    /// <param name="engineCutoff">
    /// The score floor the scorer drops seeds below, before any callback. Null takes the filter's
    /// own <c>cutoff:</c>, or no floor when it has none; <see cref="int.MinValue"/> is no floor
    /// whatever the filter says (a host whose own cutoff mode wins, as the CLI's --cutoff does).
    /// </param>
    public static IMotelySearchSettings CreateSettings(JamlConfig config, int? engineCutoff = null)
    {
        int floor = engineCutoff ?? config.Cutoff ?? int.MinValue;

        // A JAML with no must/should/mustNot clauses is a valid, real search: deck/stake/seeds
        // and nothing else, with the host's own predicate free to drive the whole decision.
        IMotelySearchSettings settings =
            new MotelySearchSettings<PassthroughFilterDesc.PassthroughFilter>(
                new PassthroughFilterDesc()
            );

        // The JAML document names its own deck and stake; the settings carry them from here so
        // every caller searches what the filter says. Callers may still override afterwards
        // (the CLI applies --deck/--stake on top).
        settings = settings.WithDeck(config.Deck).WithStake(config.Stake).WithSourceConfig(config);

        // A mustNot may only be negated in SIMD when its prefilter is the exact match law: a
        // coarse prefilter passes every lane that might hold the item, so its negation would
        // drop those seeds (a bare legendaryJoker passes all lanes and would reject everything).
        // Coarse mustNot clauses skip the chain and are rejected by the scalar scoring pass.
        var simdMustNot = config.MustNot.Where(ClauseScoring.IsExactFilterConfirm).ToArray();
        var scoredMustNot = config.MustNot.Where(c => !ClauseScoring.IsExactFilterConfirm(c)).ToArray();

        // SIMD filter chain: must + mustNot cheapest-first so trivial clauses reject lanes before
        // expensive SearchIndividualSeeds arms. Does not mutate the config; scoring still sees
        // authored must/should order (tally columns + must re-eval). A must that zero occurrences
        // satisfy (min: 0) stays out: the scoring pass re-evaluates every must, so it still holds.
        foreach (
            var (clause, negate) in config
                .Must.Where(ClauseScoring.CanChainInSimd)
                .Select(c => (clause: c, negate: false))
                .Concat(simdMustNot.Select(c => (clause: c, negate: true)))
        )
        {
            var desc = clause.CreateFilterDesc();
            settings = settings.WithAdditionalFilter(
                negate ? new NegationFilterDesc(desc) : desc
            );
        }

        if (config.Must.Count + config.Should.Count + scoredMustNot.Length > 0)
        {
            settings = settings.WithSeedScoreProvider(
                new JamlShouldScoreDesc(
                    [.. config.Must],
                    [.. config.Should],
                    minimumTotalScore: floor,
                    mustNotClauses: scoredMustNot
                )
            );
        }

        return settings;
    }
}
