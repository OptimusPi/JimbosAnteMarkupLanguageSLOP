using YamlDotNet.Core;
using YamlDotNet.Core.Events;
using YamlDotNet.Serialization;

namespace Motely.Filters;

/// <summary>
/// A JAML enum value is a name, matched case-insensitively. <c>Enum.Parse</c> on its own also reads
/// a number as the enum's value and <c>A, B</c> as <c>A | B</c>, so <c>erraticRank: 2</c> bound
/// Four (Two is 0) and <c>rank: "10"</c> bound Queen, with no error. Those forms throw here.
/// </summary>
internal static class JamlEnumName
{
    /// <summary>
    /// Enums whose value is what the number says: <see cref="MotelyLuck"/>'s value is the
    /// multiplier (<c>X4 = 4</c>), so <c>luck: 4</c> is X4. The number must be one of its values.
    /// </summary>
    public static bool NumberIsValue(Type enumType) => enumType == typeof(MotelyLuck);

    public static T Parse<T>(string text) where T : struct, Enum => (T)Parse(typeof(T), text);

    public static object Parse(Type enumType, string text)
    {
        var trimmed = text.AsSpan().Trim();
        if (IsSignedIntegerLiteral(trimmed))
        {
            if (NumberIsValue(enumType)
                && int.TryParse(trimmed, System.Globalization.NumberStyles.None,
                    System.Globalization.CultureInfo.InvariantCulture, out int number)
                && Enum.IsDefined(enumType, number))
                return Enum.ToObject(enumType, number);
            throw new FormatException(NumberIsValue(enumType)
                ? $"'{text}' is not a value: write one of {string.Join(", ", Enum.GetNames(enumType))}, or its number."
                : $"'{text}' is not a name: write {Names(enumType)}.");
        }
        if (trimmed.Contains(','))
            throw new FormatException($"'{text}' holds more than one name: a list goes in brackets, [{text}].");
        if (Enum.TryParse(enumType, text, ignoreCase: true, out var exact))
            return exact;
        throw new FormatException(NotANameMessage(enumType, text.Trim()));
    }

    private static bool IsSignedIntegerLiteral(ReadOnlySpan<char> s)
    {
        if (s.Length == 0)
            return false;
        int start = s[0] is '-' or '+' ? 1 : 0;
        if (start >= s.Length)
            return false;
        for (int i = start; i < s.Length; i++)
        {
            if (!char.IsAsciiDigit(s[i]))
                return false;
        }
        return true;
    }

    /// <summary>
    /// Why <paramref name="text"/> is no <paramref name="enumType"/> name, in one line that names the
    /// fix: the clause key it belongs under when it names something else (Certificate is a joker,
    /// Showman an uncommon joker), else the closest names.
    /// </summary>
    private static string NotANameMessage(Type enumType, string text)
    {
        var kind = Kind(enumType);
        return $"'{text}' is not {Article(kind)} {kind} name: write {Names(enumType)}.";
    }

    /// <summary>What an enum names, in the words the clause-key messages use.</summary>
    internal static string Kind(Type enumType) =>
        enumType.Name switch
        {
            nameof(MotelyJoker) => "joker",
            nameof(MotelyJokerCommon) => "common joker",
            nameof(MotelyJokerUncommon) => "uncommon joker",
            nameof(MotelyJokerRare) => "rare joker",
            nameof(MotelyJokerLegendary) => "legendary joker",
            nameof(MotelyBossBlind) => "boss",
            nameof(MotelyVoucher) => "voucher",
            nameof(MotelyTag) => "tag",
            nameof(MotelyTarotCard) => "tarot card",
            nameof(MotelyPlanetCard) => "planet card",
            nameof(MotelySpectralCard) => "spectral card",
            nameof(MotelyStandardCard) => "standard card",
            nameof(MotelyStandardcardRank) => "rank",
            nameof(MotelyStandardcardSuit) => "suit",
            nameof(MotelyItemEdition) => "edition",
            nameof(MotelyItemEnhancement) => "enhancement",
            nameof(MotelyItemSeal) => "seal",
            nameof(MotelyBoosterPack) => "booster pack",
            nameof(MotelyPokerHand) => "poker hand",
            nameof(MotelyDeck) => "deck",
            nameof(MotelyStake) => "stake",
            _ => enumType.Name.StartsWith("Motely", StringComparison.Ordinal) ? enumType.Name["Motely".Length..] : enumType.Name,
        };

    private static string Article(string word) => word.Length > 0 && "aeiouAEIOU".Contains(word[0]) ? "an" : "a";

    private static string Names(Type enumType)
    {
        var names = Enum.GetNames(enumType);
        return names.Length <= 16
            ? "one of " + string.Join(", ", names)
            : "a name such as " + string.Join(", ", names.Take(3));
    }
}

/// <summary>
/// Every enum-typed scalar — <c>deck</c>, <c>edition</c>, <c>erraticRank</c>, a <c>stickers</c>
/// entry — binds through <see cref="JamlEnumName"/>. YAML's null forms fall through to the
/// deserializer below this one, as before.
/// </summary>
internal sealed class JamlEnumNodeDeserializer : INodeDeserializer
{
    public bool Deserialize(
        IParser reader,
        Type expectedType,
        Func<IParser, Type, object?> nestedObjectDeserializer,
        out object? value,
        ObjectDeserializer rootDeserializer
    )
    {
        value = null;
        var enumType = Nullable.GetUnderlyingType(expectedType) ?? expectedType;
        if (!enumType.IsEnum || reader.Current is not Scalar scalar || IsNull(scalar))
            return false;

        reader.Consume<Scalar>();
        value = JamlEnumName.Parse(enumType, scalar.Value);
        return true;
    }

    private static bool IsNull(Scalar scalar) =>
        scalar.Tag == "tag:yaml.org,2002:null"
        || scalar.Style == ScalarStyle.Plain && scalar.Value is "" or "~" or "null" or "Null" or "NULL";
}
