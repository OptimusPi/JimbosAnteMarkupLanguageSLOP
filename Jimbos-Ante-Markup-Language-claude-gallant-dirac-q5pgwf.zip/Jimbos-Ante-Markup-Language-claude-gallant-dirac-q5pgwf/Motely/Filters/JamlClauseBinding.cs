using System.Collections.Frozen;
using YamlDotNet.Core;
using YamlDotNet.Core.Events;
using YamlDotNet.Serialization;
namespace Motely.Filters;

/// <summary>JAML clause discriminators, scalar-or-list converters, and logic-clause payloads.</summary>
internal static class JamlClauseBinding
{
    internal static IReadOnlyCollection<string> ClauseKeys => DiscriminatorKeys;

    internal static IEnumerable<IYamlTypeConverter> Converters =>
    [
        new ScalarOrSequenceConverter<MotelyJoker>(),
        new ScalarOrSequenceConverter<MotelyJokerCommon>(),
        new ScalarOrSequenceConverter<MotelyJokerUncommon>(),
        new ScalarOrSequenceConverter<MotelyJokerRare>(),
        new ScalarOrSequenceConverter<MotelyJokerLegendary>(),
        new ScalarOrSequenceConverter<MotelyPlanetCard>(),
        new ScalarOrSequenceConverter<MotelySpectralCard>(),
        new ScalarOrSequenceConverter<MotelyTarotCard>(),
        new ScalarOrSequenceConverter<MotelyVoucher>(),
        new ScalarOrSequenceConverter<MotelyTag>(),
        new ScalarOrSequenceConverter<MotelyBossBlind>(),
        new ScalarOrSequenceConverter<MotelyBoosterPack>(),
        new ScalarOrSequenceConverter<MotelyPokerHand>(),
        new IntListConverter(),
        new JamlEventRolls.Converter(),
        new JamlStandardCardSlotConverter(),
    ];

    internal static readonly Dictionary<string, Type> ClauseTypeByKey = new(StringComparer.OrdinalIgnoreCase)
    {
        ["joker"] = typeof(JokerClause),
        ["commonJoker"] = typeof(CommonJokerClause),
        ["uncommonJoker"] = typeof(UncommonJokerClause),
        ["rareJoker"] = typeof(RareJokerClause),
        ["legendaryJoker"] = typeof(LegendaryJokerClause),
        ["soulJoker"] = typeof(LegendaryJokerClause),
        ["planetCard"] = typeof(PlanetCardClause),
        ["spectralCard"] = typeof(SpectralCardClause),
        ["tarotCard"] = typeof(TarotCardClause),
        ["standardCard"] = typeof(StandardCardClause),
        ["erraticRank"] = typeof(ErraticRankClause),
        ["erraticSuit"] = typeof(ErraticSuitClause),
        ["voucher"] = typeof(VoucherClause),
        ["tag"] = typeof(TagClause),
        ["smallBlindTag"] = typeof(SmallBlindTagClause),
        ["bigBlindTag"] = typeof(BigBlindTagClause),
        ["boss"] = typeof(BossClause),
        ["boosterPack"] = typeof(BoosterPackClause),
        ["pokerHand"] = typeof(PokerHandClause),
        ["startingDraw"] = typeof(StartingDrawClause),
        ["luckyMoney"] = typeof(LuckyMoneyClause),
        ["luckyMult"] = typeof(LuckyMultClause),
        ["misprintMult"] = typeof(MisprintMultClause),
        ["wheelOfFortune"] = typeof(WheelOfFortuneClause),
        ["wheelStaysFlipped"] = typeof(WheelStaysFlippedClause),
        ["glassDestroy"] = typeof(GlassDestroyClause),
        ["cavendishExtinct"] = typeof(CavendishExtinctClause),
        ["grosMichelExtinct"] = typeof(GrosMichelExtinctClause),
        ["spaceLevelup"] = typeof(SpaceLevelupClause),
        ["businessPayout"] = typeof(BusinessPayoutClause),
        ["parkingPayout"] = typeof(ParkingPayoutClause),
        ["bloodstoneTrigger"] = typeof(BloodstoneTriggerClause),
        ["and"] = typeof(AndClause),
        ["or"] = typeof(OrClause),
        ["soulOrder"] = typeof(LegendarySoulOrderClause),
    };

    private static readonly FrozenSet<string> DiscriminatorKeys =
        ClauseTypeByKey.Keys.ToFrozenSet(StringComparer.OrdinalIgnoreCase);

    /// <summary>Scalar, empty, <c>any</c>, or sequence → array (Nat's JAML filter clauses).</summary>
    internal sealed class ScalarOrSequenceConverter<T> : IYamlTypeConverter
    {
        private readonly Type _arrayType = typeof(T[]);

        public bool Accepts(Type type) => type == _arrayType;

        public object ReadYaml(IParser parser, Type type, ObjectDeserializer nested) =>
            parser.Current switch
            {
                SequenceStart => ReadSequence(parser),
                Scalar scalar when IsCategoryAny(scalar) => ConsumeAndReturn(parser, Array.Empty<T>()),
                Scalar scalar when typeof(T) == typeof(int) => ConsumeAndReturn(
                    parser,
                    new[] { int.Parse(scalar.Value, System.Globalization.CultureInfo.InvariantCulture) }
                ),
                Scalar scalar => ConsumeAndReturn(
                    parser,
                    new[] { (T)JamlEnumName.Parse(typeof(T), scalar.Value) }
                ),
                _ => Array.Empty<T>(),
            };

        private static T[] ReadSequence(IParser parser)
        {
            parser.Consume<SequenceStart>();
            var items = new List<T>();
            while (!parser.TryConsume<SequenceEnd>(out _))
            {
                var scalar = parser.Consume<Scalar>();
                items.Add((T)JamlEnumName.Parse(typeof(T), scalar.Value));
            }

            return items.ToArray();
        }

        private static TResult ConsumeAndReturn<TResult>(IParser parser, TResult value)
        {
            parser.Consume<Scalar>();
            return value;
        }

        public void WriteYaml(IEmitter emitter, object? value, Type type, ObjectSerializer nested) =>
            nested(value, type);
    }

    /// <summary>
    /// A list of numbers (<c>antes</c>, <c>shopItems</c>, …) as a list, or as one number for a list
    /// of one: <c>ante: 2</c> is <c>antes: [2]</c>. Each number reads as YamlDotNet reads an int; a
    /// null value stays null, as without this converter.
    /// </summary>
    internal sealed class IntListConverter : IYamlTypeConverter
    {
        public bool Accepts(Type type) => type == typeof(int[]);

        public object? ReadYaml(IParser parser, Type type, ObjectDeserializer nested)
        {
            if (parser.Current is Scalar scalar && scalar.Style == ScalarStyle.Plain && scalar.Value is "" or "~" or "null" or "Null" or "NULL")
            {
                parser.MoveNext();
                return null;
            }
            if (parser.Current is not SequenceStart)
                return new[] { Number(parser, nested) };

            parser.Consume<SequenceStart>();
            var items = new List<int>();
            while (!parser.TryConsume<SequenceEnd>(out _))
                items.Add(Number(parser, nested));
            return items.ToArray();
        }

        private static int Number(IParser parser, ObjectDeserializer nested)
        {
            if (parser.Current is not Scalar scalar)
            {
                var ev = parser.Current ?? throw new FormatException(
                    "a nested list is not a number: write a whole number, or a list of them, as in [1, 2].");
                throw new YamlException(
                    ev.Start,
                    ev.End,
                    "a nested list is not a number: write a whole number, or a list of them, as in [1, 2]."
                );
            }

            var text = scalar.Value;
            int value;
            try
            {
                value = (int)nested(typeof(int))!;
            }
            catch (Exception ex) when (text is not null && ex is FormatException or OverflowException or YamlException)
            {
                throw new FormatException($"'{text}' is not a number: write a whole number, or a list of them, as in [1, 2].", ex);
            }
            if (value is < 0 or > MotelyGlobals.MaxRollIndex)
                throw new YamlException(scalar.Start, scalar.End, $"`{value}` is out of range: a number in this list runs from 0 to {MotelyGlobals.MaxRollIndex}.");
            return value;
        }

        public void WriteYaml(IEmitter emitter, object? value, Type type, ObjectSerializer nested) =>
            nested(value, type);
    }

    private static bool IsCategoryAny(Scalar scalar)
    {
        if (scalar.Style is not (ScalarStyle.Plain or ScalarStyle.SingleQuoted or ScalarStyle.DoubleQuoted))
            return false;
        var text = scalar.Value.Trim();
        return text.Length == 0
            || text.Equals("any", StringComparison.OrdinalIgnoreCase)
            || text.Equals("~", StringComparison.OrdinalIgnoreCase)
            || text.Equals("null", StringComparison.OrdinalIgnoreCase);
    }
}
