using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.Intrinsics;

namespace Motely.Filters;

/// <summary>
/// Shop booster pack <em>offer</em> filter: which pack kind+size sits in which pack slot.
/// Does not open pack contents — that is tarot/joker/planet/standard sources.
/// Value enum is <see cref="MotelyBoosterPack"/> (already in Motely.Enums; no new enum).
/// </summary>
[YamlDotNet.Serialization.YamlSerializable]
public sealed partial class BoosterPackClause: IMotelyClause, IAnteScopedClause, IRollScopedClause
{
    public MotelyBoosterPack[]? BoosterPack { get => Packs; set => Packs = value ?? []; }
    public MotelyBoosterPack[]? BoosterPacks { get => Packs; set => Packs = value ?? []; }

    /// <summary><c>ante: 2</c> or <c>ante: [1, 2]</c> is <c>antes:</c>.</summary>
    public int[]? Ante { get => null; set => Antes = value ?? Antes; }

    public string? Label { get; set; }
    public int Min { get; set; } = 1;
    public int? Max { get; set; }
    public int Score { get; set; } = 1;
    public int[] Antes { get; set; } = [1, 2, 3, 4, 5, 6, 7, 8];

    /// <summary>
    /// Pack identities (type + size). Empty = any pack in the targeted slots (category match).
    /// </summary>
    public MotelyBoosterPack[] Packs { get; set; } = [];

    /// <summary>
    /// Shop pack offer indices per ante (0 = first offer, 1 = second, …).
    /// Same index space as other filters' <c>boosterPacks:</c> source lists.
    /// </summary>
    public int[] Rolls { get; set; } = [0, 1];

    public IMotelySeedFilterDesc CreateFilterDesc() => new BoosterPackFilterDesc(this);
}

public struct BoosterPackFilterDesc(BoosterPackClause clause)
    : IMotelySeedFilterDesc<BoosterPackFilterDesc.BoosterPackFilter>
{
    private readonly BoosterPackClause _clause = clause;

    public BoosterPackFilter CreateFilter(ref MotelyFilterCreationContext ctx)
    {
        foreach (var ante in _clause.Antes)
            ctx.CacheBoosterPackStream(ante);
        return new BoosterPackFilter(_clause);
    }

    public struct BoosterPackFilter(BoosterPackClause clause) : IMotelySeedFilter
    {
        private readonly BoosterPackClause _clause = clause;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public VectorMask Filter(ref MotelyVectorSearchContext ctx)
        {
            var clause = _clause;
            int maxSlot = (clause.Rolls.Length == 0 ? -1 : clause.Rolls.Max());
            Debug.Assert(maxSlot >= 0, "BoosterPack rolls empty after load — loader bug.");

            Vector256<int> matchCounts = Vector256<int>.Zero;

            VectorMask ante1Extended = VectorMask.NoBitsSet;
            if (SimdPackSupport.NeedsAnte1Extension(maxSlot))
            {
                bool hasAnte1 = false;
                for (int i = 0; i < clause.Antes.Length; i++)
                {
                    if (clause.Antes[i] == 1)
                    {
                        hasAnte1 = true;
                        break;
                    }
                }
                if (hasAnte1)
                    ante1Extended = SimdPackSupport.Ante1PackExtensionMask(ref ctx);
            }

            foreach (var ante in clause.Antes)
            {
                var packStream = ctx.CreateBoosterPackStream(ante);
                for (int p = 0; p <= maxSlot; p++)
                {
                    var pack = ctx.GetNextBoosterPack(ref packStream);

                    bool isTarget = false;
                    for (int i = 0; i < clause.Rolls.Length; i++)
                    {
                        if (clause.Rolls[i] == p)
                        {
                            isTarget = true;
                            break;
                        }
                    }
                    if (!isTarget)
                        continue;

                    VectorMask reachable = SimdPackSupport.SlotReachableMask(
                        ante,
                        p,
                        ante1Extended
                    );
                    if (reachable.IsAllFalse())
                        continue;

                    VectorMask hit;
                    if ((clause.Packs.Length == 0))
                    {
                        hit = reachable;
                    }
                    else
                    {
                        hit = VectorMask.NoBitsSet;
                        for (int t = 0; t < clause.Packs.Length; t++)
                            hit |= VectorEnum256.Equals(pack, clause.Packs[t]);
                        hit &= reachable;
                    }

                    SimdPackSupport.AddMatchCounts(hit, ref matchCounts);
                }
            }

            return SimdPackSupport.MeetsMinMaxMask(matchCounts, clause.Min, clause.Max);
        }
    }
}
