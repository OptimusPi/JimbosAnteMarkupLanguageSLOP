// The filter shapes the engine's loader binds. Kept by hand since the generator (tools/schema.cs) left the tree:
// change it with the clause classes in Motely/Filters. A filter is plain JSON: build a JamlFilter, hand
// JSON.stringify(filter) to JamlConfigLoader.check or fromJaml, and read one back with JSON.parse.

export type MotelyJokerName = "Joker" | "GreedyJoker" | "LustyJoker" | "WrathfulJoker" | "GluttonousJoker" | "JollyJoker" | "ZanyJoker" | "MadJoker" | "CrazyJoker" | "DrollJoker" | "SlyJoker" | "WilyJoker" | "CleverJoker" | "DeviousJoker" | "CraftyJoker" | "HalfJoker" | "CreditCard" | "Banner" | "MysticSummit" | "EightBall" | "Misprint" | "RaisedFist" | "ChaostheClown" | "ScaryFace" | "AbstractJoker" | "DelayedGratification" | "GrosMichel" | "EvenSteven" | "OddTodd" | "Scholar" | "BusinessCard" | "Supernova" | "RideTheBus" | "Egg" | "Runner" | "IceCream" | "Splash" | "BlueJoker" | "FacelessJoker" | "GreenJoker" | "Superposition" | "ToDoList" | "Cavendish" | "RedCard" | "SquareJoker" | "RiffRaff" | "Photograph" | "ReservedParking" | "MailInRebate" | "Hallucination" | "FortuneTeller" | "Juggler" | "Drunkard" | "GoldenJoker" | "Popcorn" | "WalkieTalkie" | "SmileyFace" | "GoldenTicket" | "Swashbuckler" | "HangingChad" | "ShootTheMoon" | "JokerStencil" | "FourFingers" | "Mime" | "CeremonialDagger" | "MarbleJoker" | "LoyaltyCard" | "Dusk" | "Fibonacci" | "SteelJoker" | "Hack" | "Pareidolia" | "SpaceJoker" | "Burglar" | "Blackboard" | "SixthSense" | "Constellation" | "Hiker" | "CardSharp" | "Madness" | "Seance" | "Vampire" | "Shortcut" | "Hologram" | "Cloud9" | "Rocket" | "MidasMask" | "Luchador" | "GiftCard" | "TurtleBean" | "Erosion" | "ToTheMoon" | "StoneJoker" | "LuckyCat" | "Bull" | "DietCola" | "TradingCard" | "FlashCard" | "SpareTrousers" | "Ramen" | "Seltzer" | "Castle" | "MrBones" | "Acrobat" | "SockAndBuskin" | "Troubadour" | "Certificate" | "SmearedJoker" | "Throwback" | "RoughGem" | "Bloodstone" | "Arrowhead" | "OnyxAgate" | "GlassJoker" | "Showman" | "FlowerPot" | "MerryAndy" | "OopsAll6s" | "TheIdol" | "SeeingDouble" | "Matador" | "Satellite" | "Cartomancer" | "Astronomer" | "Bootstraps" | "DNA" | "Vagabond" | "Baron" | "Obelisk" | "BaseballCard" | "AncientJoker" | "Campfire" | "Blueprint" | "WeeJoker" | "HitTheRoad" | "TheDuo" | "TheTrio" | "TheFamily" | "TheOrder" | "TheTribe" | "Stuntman" | "InvisibleJoker" | "Brainstorm" | "DriversLicense" | "BurntJoker" | "Canio" | "Triboulet" | "Yorick" | "Chicot" | "Perkeo";
export type MotelyLuckName = "X1" | "X2" | "X4" | "X5" | "X8" | "X16" | "X32" | "X64" | 1 | 2 | 4 | 5 | 8 | 16 | 32 | 64;
export type MotelyItemEditionName = "None" | "Foil" | "Holographic" | "Polychrome" | "Negative";
export type MotelyJokerStickerName = "None" | "Eternal" | "Perishable" | "Rental";
export type MotelyJokerCommonName = "Joker" | "GreedyJoker" | "LustyJoker" | "WrathfulJoker" | "GluttonousJoker" | "JollyJoker" | "ZanyJoker" | "MadJoker" | "CrazyJoker" | "DrollJoker" | "SlyJoker" | "WilyJoker" | "CleverJoker" | "DeviousJoker" | "CraftyJoker" | "HalfJoker" | "CreditCard" | "Banner" | "MysticSummit" | "EightBall" | "Misprint" | "RaisedFist" | "ChaostheClown" | "ScaryFace" | "AbstractJoker" | "DelayedGratification" | "GrosMichel" | "EvenSteven" | "OddTodd" | "Scholar" | "BusinessCard" | "Supernova" | "RideTheBus" | "Egg" | "Runner" | "IceCream" | "Splash" | "BlueJoker" | "FacelessJoker" | "GreenJoker" | "Superposition" | "ToDoList" | "Cavendish" | "RedCard" | "SquareJoker" | "RiffRaff" | "Photograph" | "ReservedParking" | "MailInRebate" | "Hallucination" | "FortuneTeller" | "Juggler" | "Drunkard" | "GoldenJoker" | "Popcorn" | "WalkieTalkie" | "SmileyFace" | "GoldenTicket" | "Swashbuckler" | "HangingChad" | "ShootTheMoon";
export type MotelyJokerUncommonName = "JokerStencil" | "FourFingers" | "Mime" | "CeremonialDagger" | "MarbleJoker" | "LoyaltyCard" | "Dusk" | "Fibonacci" | "SteelJoker" | "Hack" | "Pareidolia" | "SpaceJoker" | "Burglar" | "Blackboard" | "SixthSense" | "Constellation" | "Hiker" | "CardSharp" | "Madness" | "Seance" | "Vampire" | "Shortcut" | "Hologram" | "Cloud9" | "Rocket" | "MidasMask" | "Luchador" | "GiftCard" | "TurtleBean" | "Erosion" | "ToTheMoon" | "StoneJoker" | "LuckyCat" | "Bull" | "DietCola" | "TradingCard" | "FlashCard" | "SpareTrousers" | "Ramen" | "Seltzer" | "Castle" | "MrBones" | "Acrobat" | "SockAndBuskin" | "Troubadour" | "Certificate" | "SmearedJoker" | "Throwback" | "RoughGem" | "Bloodstone" | "Arrowhead" | "OnyxAgate" | "GlassJoker" | "Showman" | "FlowerPot" | "MerryAndy" | "OopsAll6s" | "TheIdol" | "SeeingDouble" | "Matador" | "Satellite" | "Cartomancer" | "Astronomer" | "Bootstraps";
export type MotelyJokerRareName = "DNA" | "Vagabond" | "Baron" | "Obelisk" | "BaseballCard" | "AncientJoker" | "Campfire" | "Blueprint" | "WeeJoker" | "HitTheRoad" | "TheDuo" | "TheTrio" | "TheFamily" | "TheOrder" | "TheTribe" | "Stuntman" | "InvisibleJoker" | "Brainstorm" | "DriversLicense" | "BurntJoker";
export type MotelyPlanetCardName = "Mercury" | "Venus" | "Earth" | "Mars" | "Jupiter" | "Saturn" | "Uranus" | "Neptune" | "Pluto" | "PlanetX" | "Ceres" | "Eris";
export type MotelySpectralCardName = "Familiar" | "Grim" | "Incantation" | "Talisman" | "Aura" | "Wraith" | "Sigil" | "Ouija" | "Ectoplasm" | "Immolate" | "Ankh" | "DejaVu" | "Hex" | "Trance" | "Medium" | "Cryptid" | "TheSoul" | "BlackHole";
export type MotelyTarotCardName = "TheFool" | "TheMagician" | "TheHighPriestess" | "TheEmpress" | "TheEmperor" | "TheHierophant" | "TheLovers" | "TheChariot" | "Justice" | "TheHermit" | "TheWheelOfFortune" | "Strength" | "TheHangedMan" | "Death" | "Temperance" | "TheDevil" | "TheTower" | "TheStar" | "TheMoon" | "TheSun" | "Judgement" | "TheWorld";
export type MotelyStandardCardName = "TwoOfClubs" | "ThreeOfClubs" | "FourOfClubs" | "FiveOfClubs" | "SixOfClubs" | "SevenOfClubs" | "EightOfClubs" | "NineOfClubs" | "TenOfClubs" | "JackOfClubs" | "QueenOfClubs" | "KingOfClubs" | "AceOfClubs" | "TwoOfDiamonds" | "ThreeOfDiamonds" | "FourOfDiamonds" | "FiveOfDiamonds" | "SixOfDiamonds" | "SevenOfDiamonds" | "EightOfDiamonds" | "NineOfDiamonds" | "TenOfDiamonds" | "JackOfDiamonds" | "QueenOfDiamonds" | "KingOfDiamonds" | "AceOfDiamonds" | "TwoOfHearts" | "ThreeOfHearts" | "FourOfHearts" | "FiveOfHearts" | "SixOfHearts" | "SevenOfHearts" | "EightOfHearts" | "NineOfHearts" | "TenOfHearts" | "JackOfHearts" | "QueenOfHearts" | "KingOfHearts" | "AceOfHearts" | "TwoOfSpades" | "ThreeOfSpades" | "FourOfSpades" | "FiveOfSpades" | "SixOfSpades" | "SevenOfSpades" | "EightOfSpades" | "NineOfSpades" | "TenOfSpades" | "JackOfSpades" | "QueenOfSpades" | "KingOfSpades" | "AceOfSpades";
export type MotelyItemEnhancementName = "None" | "Bonus" | "Mult" | "Wild" | "Glass" | "Steel" | "Stone" | "Gold" | "Lucky";
export type MotelyStandardcardRankName = "Two" | "Three" | "Four" | "Five" | "Six" | "Seven" | "Eight" | "Nine" | "Ten" | "Jack" | "Queen" | "King" | "Ace";
export type MotelyItemSealName = "None" | "Gold" | "Red" | "Blue" | "Purple";
export type MotelyStandardcardSuitName = "Clubs" | "Diamonds" | "Hearts" | "Spades";
export type MotelyVoucherName = "Overstock" | "OverstockPlus" | "ClearanceSale" | "Liquidation" | "Hone" | "GlowUp" | "RerollSurplus" | "RerollGlut" | "CrystalBall" | "OmenGlobe" | "Telescope" | "Observatory" | "Grabber" | "NachoTong" | "Wasteful" | "Recyclomancy" | "TarotMerchant" | "TarotTycoon" | "PlanetMerchant" | "PlanetTycoon" | "SeedMoney" | "MoneyTree" | "Blank" | "Antimatter" | "MagicTrick" | "Illusion" | "Hieroglyph" | "Petroglyph" | "DirectorsCut" | "Retcon" | "PaintBrush" | "Palette";
export type MotelyTagName = "UncommonTag" | "RareTag" | "NegativeTag" | "FoilTag" | "HolographicTag" | "PolychromeTag" | "InvestmentTag" | "VoucherTag" | "BossTag" | "StandardTag" | "CharmTag" | "MeteorTag" | "BuffoonTag" | "HandyTag" | "GarbageTag" | "EtherealTag" | "CouponTag" | "DoubleTag" | "JuggleTag" | "D6Tag" | "TopupTag" | "SpeedTag" | "OrbitalTag" | "EconomyTag";
export type MotelyBossBlindName = "TheClub" | "TheGoad" | "TheHead" | "TheHook" | "TheManacle" | "ThePillar" | "ThePsychic" | "TheWindow" | "TheArm" | "TheFish" | "TheFlint" | "TheHouse" | "TheMark" | "TheMouth" | "TheNeedle" | "TheWall" | "TheWater" | "TheWheel" | "TheEye" | "TheTooth" | "ThePlant" | "TheSerpent" | "TheOx" | "AmberAcorn" | "CeruleanBell" | "CrimsonHeart" | "VerdantLeaf" | "VioletVessel";
export type MotelyBoosterPackName = "Arcana" | "JumboArcana" | "MegaArcana" | "Celestial" | "JumboCelestial" | "MegaCelestial" | "Standard" | "JumboStandard" | "MegaStandard" | "Buffoon" | "JumboBuffoon" | "MegaBuffoon" | "Spectral" | "JumboSpectral" | "MegaSpectral";
export type MotelyPokerHandName = "HighCard" | "Pair" | "TwoPair" | "ThreeOfAKind" | "Straight" | "Flush" | "FullHouse" | "FourOfAKind" | "StraightFlush";
export type LogicScoreModeName = "Sum" | "Max";
export type MotelyDeckName = "Red" | "Blue" | "Yellow" | "Green" | "Black" | "Magic" | "Nebula" | "Ghost" | "Abandoned" | "Checkered" | "Zodiac" | "Painted" | "Anaglyph" | "Plasma" | "Erratic";
export type MotelyStakeName = "White" | "Red" | "Green" | "Black" | "Blue" | "Purple" | "Orange" | "Gold";

/** A whole filter document, as the engine loads it from YAML or JSON. */
export interface JamlFilter {
  id?: string | number | boolean | null;
  name?: string | number | boolean | null;
  description?: string | number | boolean | null;
  author?: string | number | boolean | null;
  dateCreated?: string | number | boolean | null;
  deck?: MotelyDeckName;
  stake?: MotelyStakeName;
  seeds?: (string | number | boolean)[];
  cutoff?: number | null;
  must?: JamlClause[];
  should?: JamlClause[];
  mustNot?: JamlClause[];
}

export interface JamlLegendaryJokerSourceConfig {
  arcanaPacks?: number | number[];
  boosterPacks?: number | number[];
  requireMega?: boolean | null;
  requireMegaPack?: boolean;
  spectralPacks?: number | number[];
  tagPacks?: number | number[];
}

export interface JamlJokerSourceConfig {
  allShopJokers?: number | number[];
  boosterPacks?: number | number[];
  commonShopJokers?: number | number[];
  judgement?: number | number[];
  rareShopJokers?: number | number[];
  rareTag?: number | number[];
  requireMega?: boolean | null;
  requireMegaPack?: boolean;
  riffRaff?: number | number[];
  shopItems?: number | number[];
  uncommonShopJokers?: number | number[];
  uncommonTag?: number | number[];
  wraith?: number | number[];
}

export interface JamlWith {
  jokers?: MotelyJokerName | "Any" | MotelyJokerName[] | null;
  luck?: MotelyLuckName;
}

export interface JamlPlanetSourceConfig {
  boosterPacks?: number | number[];
  requireMega?: boolean | null;
  requireMegaPack?: boolean;
  shopItems?: number | number[];
}

export interface JamlSpectralCardSourceConfig {
  boosterPacks?: number | number[];
  etherealTag?: boolean;
  omenGlobe?: boolean;
  requireMega?: boolean | null;
  requireMegaPack?: boolean;
  seance?: number | number[];
  shopItems?: number | number[];
  sixthSense?: number | number[];
}

export interface JamlTarotCardSourceConfig {
  boosterPacks?: number | number[];
  charmTag?: boolean;
  emperor?: number | number[];
  purpleSealOrEightBall?: number | number[];
  requireMega?: boolean | null;
  requireMegaPack?: boolean;
  shopItems?: number | number[];
  tagPacks?: number | number[];
}

export interface JamlStandardCardSourceConfig {
  boosterPacks?: number | number[];
  requireMega?: boolean | null;
  requireMegaPack?: boolean;
  shopItems?: number | number[];
}

export interface JamlSoulOrderEntry {
  antes?: number | number[];
  legendary?: MotelyJokerName;
}

export interface JamlJokerClause {
  ante?: number | number[];
  antes?: number | number[];
  edition?: MotelyItemEditionName | null;
  joker?: MotelyJokerName | "Any" | MotelyJokerName[] | null;
  jokers?: MotelyJokerName | "Any" | MotelyJokerName[] | null;
  label?: string | number | boolean | null;
  legendarySources?: JamlLegendaryJokerSourceConfig | null;
  max?: number | null;
  min?: number;
  score?: number;
  sources?: JamlJokerSourceConfig | null;
  stickers?: MotelyJokerStickerName | "Any" | MotelyJokerStickerName[] | null;
}

export interface JamlCommonJokerClause {
  ante?: number | number[];
  antes?: number | number[];
  commonJoker?: MotelyJokerCommonName | "Any" | MotelyJokerCommonName[] | null;
  commonJokers?: MotelyJokerCommonName | "Any" | MotelyJokerCommonName[] | null;
  edition?: MotelyItemEditionName | null;
  jokers?: MotelyJokerCommonName | "Any" | MotelyJokerCommonName[] | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  score?: number;
  sources?: JamlJokerSourceConfig | null;
  stickers?: MotelyJokerStickerName | "Any" | MotelyJokerStickerName[] | null;
}

export interface JamlUncommonJokerClause {
  ante?: number | number[];
  antes?: number | number[];
  edition?: MotelyItemEditionName | null;
  jokers?: MotelyJokerUncommonName | "Any" | MotelyJokerUncommonName[] | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  score?: number;
  sources?: JamlJokerSourceConfig | null;
  stickers?: MotelyJokerStickerName | "Any" | MotelyJokerStickerName[] | null;
  uncommonJoker?: MotelyJokerUncommonName | "Any" | MotelyJokerUncommonName[] | null;
  uncommonJokers?: MotelyJokerUncommonName | "Any" | MotelyJokerUncommonName[] | null;
}

export interface JamlRareJokerClause {
  ante?: number | number[];
  antes?: number | number[];
  edition?: MotelyItemEditionName | null;
  jokers?: MotelyJokerRareName | "Any" | MotelyJokerRareName[] | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rareJoker?: MotelyJokerRareName | "Any" | MotelyJokerRareName[] | null;
  rareJokers?: MotelyJokerRareName | "Any" | MotelyJokerRareName[] | null;
  score?: number;
  sources?: JamlJokerSourceConfig | null;
  stickers?: MotelyJokerStickerName | "Any" | MotelyJokerStickerName[] | null;
}

export interface JamlLegendaryJokerClause {
  ante?: number | number[];
  antes?: number | number[];
  edition?: MotelyItemEditionName | null;
  jokers?: MotelyJokerName | "Any" | MotelyJokerName[] | null;
  label?: string | number | boolean | null;
  legendaryJoker?: MotelyJokerName | "Any" | MotelyJokerName[] | null;
  legendaryJokers?: MotelyJokerName | "Any" | MotelyJokerName[] | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  soulCardOnly?: boolean;
  soulEditionRolls?: number;
  soulJoker?: MotelyJokerName | "Any" | MotelyJokerName[] | null;
  sources?: JamlLegendaryJokerSourceConfig | null;
  with?: JamlWith | null;
}

export interface JamlPlanetCardClause {
  ante?: number | number[];
  antes?: number | number[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  planetCard?: MotelyPlanetCardName | "Any" | MotelyPlanetCardName[] | null;
  planetCards?: MotelyPlanetCardName | "Any" | MotelyPlanetCardName[] | null;
  planets?: MotelyPlanetCardName | "Any" | MotelyPlanetCardName[] | null;
  score?: number;
  sources?: JamlPlanetSourceConfig | null;
}

export interface JamlSpectralCardClause {
  ante?: number | number[];
  antes?: number | number[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  score?: number;
  sources?: JamlSpectralCardSourceConfig | null;
  spectralCard?: MotelySpectralCardName | "Any" | MotelySpectralCardName[] | null;
  spectralCards?: MotelySpectralCardName | "Any" | MotelySpectralCardName[] | null;
  spectrals?: MotelySpectralCardName | "Any" | MotelySpectralCardName[] | null;
}

export interface JamlTarotCardClause {
  ante?: number | number[];
  antes?: number | number[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  score?: number;
  sources?: JamlTarotCardSourceConfig | null;
  tarotCard?: MotelyTarotCardName | "Any" | MotelyTarotCardName[] | null;
  tarotCards?: MotelyTarotCardName | "Any" | MotelyTarotCardName[] | null;
  tarots?: MotelyTarotCardName | "Any" | MotelyTarotCardName[] | null;
}

export interface JamlStandardCardClause {
  ante?: number | number[];
  antes?: number | number[];
  card?: MotelyStandardCardName | null;
  edition?: MotelyItemEditionName | null;
  enhancement?: MotelyItemEnhancementName | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rank?: MotelyStandardcardRankName | null;
  score?: number;
  seal?: MotelyItemSealName | null;
  sources?: JamlStandardCardSourceConfig | null;
  standardCard?: MotelyStandardCardName | "Any" | JamlStandardCardSlot | null;
  standardCards?: MotelyStandardCardName | "Any" | JamlStandardCardSlot | null;
  suit?: MotelyStandardcardSuitName | null;
}

export interface JamlStandardCardSlot {
  card?: MotelyStandardCardName | null;
  edition?: MotelyItemEditionName | null;
  enhancement?: MotelyItemEnhancementName | null;
  rank?: MotelyStandardcardRankName | null;
  seal?: MotelyItemSealName | null;
  suit?: MotelyStandardcardSuitName | null;
}

export interface JamlErraticRankClause {
  ante?: number | number[];
  antes?: number | number[];
  erraticRank?: MotelyStandardcardRankName | null;
  erraticRanks?: MotelyStandardcardRankName | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rank?: MotelyStandardcardRankName;
  score?: number;
}

export interface JamlErraticSuitClause {
  ante?: number | number[];
  antes?: number | number[];
  erraticSuit?: MotelyStandardcardSuitName | null;
  erraticSuits?: MotelyStandardcardSuitName | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  score?: number;
  suit?: MotelyStandardcardSuitName;
}

export interface JamlVoucherClause {
  ante?: number | number[];
  antes?: number | number[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  voucher?: MotelyVoucherName | "Any" | MotelyVoucherName[] | null;
  vouchers?: MotelyVoucherName | "Any" | MotelyVoucherName[] | null;
}

export interface JamlTagClause {
  ante?: number | number[];
  antes?: number | number[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  tag?: MotelyTagName | "Any" | MotelyTagName[] | null;
  tags?: MotelyTagName | "Any" | MotelyTagName[] | null;
}

export interface JamlSmallBlindTagClause {
  ante?: number | number[];
  antes?: number | number[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  smallBlindTag?: MotelyTagName | "Any" | MotelyTagName[] | null;
  tag?: MotelyTagName | "Any" | MotelyTagName[] | null;
  tags?: MotelyTagName | "Any" | MotelyTagName[] | null;
}

export interface JamlBigBlindTagClause {
  ante?: number | number[];
  antes?: number | number[];
  bigBlindTag?: MotelyTagName | "Any" | MotelyTagName[] | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  tag?: MotelyTagName | "Any" | MotelyTagName[] | null;
  tags?: MotelyTagName | "Any" | MotelyTagName[] | null;
}

export interface JamlBossClause {
  ante?: number | number[];
  antes?: number | number[];
  boss?: MotelyBossBlindName | "Any" | MotelyBossBlindName[] | null;
  bosses?: MotelyBossBlindName | "Any" | MotelyBossBlindName[] | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  score?: number;
}

export interface JamlBoosterPackClause {
  ante?: number | number[];
  antes?: number | number[];
  boosterPack?: MotelyBoosterPackName | "Any" | MotelyBoosterPackName[] | null;
  boosterPacks?: MotelyBoosterPackName | "Any" | MotelyBoosterPackName[] | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  packs?: MotelyBoosterPackName | "Any" | MotelyBoosterPackName[] | null;
  rolls?: number | number[];
  score?: number;
}

export interface JamlPokerHandClause {
  ante?: number | number[];
  antes?: number | number[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  pokerHand?: MotelyPokerHandName | "Any" | MotelyPokerHandName[] | null;
  pokerHands?: MotelyPokerHandName | "Any" | MotelyPokerHandName[] | null;
  rolls?: number | number[];
  score?: number;
}

export interface JamlStartingDrawClause {
  ante?: number | number[];
  antes?: number | number[];
  card?: MotelyStandardCardName | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rank?: MotelyStandardcardRankName | null;
  score?: number;
  startingDraw?: MotelyStandardCardName | null;
  suit?: MotelyStandardcardSuitName | null;
}

export interface JamlLuckyMoneyClause {
  label?: string | number | boolean | null;
  luckyMoney?: number | number[] | "Any" | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  with?: JamlWith | null;
}

export interface JamlLuckyMultClause {
  label?: string | number | boolean | null;
  luckyMult?: number | number[] | "Any" | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  with?: JamlWith | null;
}

export interface JamlMisprintMultClause {
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  misprintMult?: number | number[] | "Any" | null;
  mult?: number;
  rolls?: number | number[];
  score?: number;
}

export interface JamlWheelOfFortuneClause {
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  wheelOfFortune?: number | number[] | "Any" | null;
  with?: JamlWith | null;
}

export interface JamlWheelStaysFlippedClause {
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  wheelStaysFlipped?: number | number[] | "Any" | null;
  with?: JamlWith | null;
}

export interface JamlGlassDestroyClause {
  glassDestroy?: number | number[] | "Any" | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  with?: JamlWith | null;
}

export interface JamlCavendishExtinctClause {
  cavendishExtinct?: number | number[] | "Any" | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  with?: JamlWith | null;
}

export interface JamlGrosMichelExtinctClause {
  grosMichelExtinct?: number | number[] | "Any" | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  with?: JamlWith | null;
}

export interface JamlSpaceLevelupClause {
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
  spaceLevelup?: number | number[] | "Any" | null;
  with?: JamlWith | null;
}

export interface JamlBusinessPayoutClause {
  businessPayout?: number | number[] | "Any" | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
}

export interface JamlParkingPayoutClause {
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  parkingPayout?: number | number[] | "Any" | null;
  rolls?: number | number[];
  score?: number;
}

export interface JamlBloodstoneTriggerClause {
  bloodstoneTrigger?: number | number[] | "Any" | null;
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  rolls?: number | number[];
  score?: number;
}

export interface JamlAndClause {
  and?: JamlClause[] | JamlAndPayload | null;
  clauses?: JamlClause[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  mode?: LogicScoreModeName;
  score?: number;
}

export interface JamlAndPayload {
  clauses?: JamlClause[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  mode?: LogicScoreModeName;
  score?: number;
}

export interface JamlOrClause {
  clauses?: JamlClause[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  mode?: LogicScoreModeName;
  or?: JamlClause[] | JamlOrPayload | null;
  score?: number;
}

export interface JamlOrPayload {
  clauses?: JamlClause[];
  label?: string | number | boolean | null;
  max?: number | null;
  min?: number;
  mode?: LogicScoreModeName;
  score?: number;
}

export interface JamlLegendarySoulOrderClause {
  boosterPacks?: number | number[];
  entries?: JamlSoulOrderEntry[];
  label?: string | number | boolean | null;
  max?: number | null;
  maxAnte?: number;
  min?: number;
  score?: number;
  soulOrder?: JamlSoulOrderEntry[];
  soulOrders?: JamlSoulOrderEntry[];
  with?: JamlWith | null;
}

export type JamlClause = JamlJokerClause & Required<Pick<JamlJokerClause, "joker">> | JamlJokerClause & Required<Pick<JamlJokerClause, "jokers">> | JamlCommonJokerClause & Required<Pick<JamlCommonJokerClause, "commonJoker">> | JamlCommonJokerClause & Required<Pick<JamlCommonJokerClause, "commonJokers">> | JamlUncommonJokerClause & Required<Pick<JamlUncommonJokerClause, "uncommonJoker">> | JamlUncommonJokerClause & Required<Pick<JamlUncommonJokerClause, "uncommonJokers">> | JamlRareJokerClause & Required<Pick<JamlRareJokerClause, "rareJoker">> | JamlRareJokerClause & Required<Pick<JamlRareJokerClause, "rareJokers">> | JamlLegendaryJokerClause & Required<Pick<JamlLegendaryJokerClause, "legendaryJoker">> | JamlLegendaryJokerClause & Required<Pick<JamlLegendaryJokerClause, "legendaryJokers">> | JamlLegendaryJokerClause & Required<Pick<JamlLegendaryJokerClause, "soulJoker">> | JamlPlanetCardClause & Required<Pick<JamlPlanetCardClause, "planetCard">> | JamlPlanetCardClause & Required<Pick<JamlPlanetCardClause, "planetCards">> | JamlSpectralCardClause & Required<Pick<JamlSpectralCardClause, "spectralCard">> | JamlSpectralCardClause & Required<Pick<JamlSpectralCardClause, "spectralCards">> | JamlTarotCardClause & Required<Pick<JamlTarotCardClause, "tarotCard">> | JamlTarotCardClause & Required<Pick<JamlTarotCardClause, "tarotCards">> | JamlStandardCardClause & Required<Pick<JamlStandardCardClause, "standardCard">> | JamlStandardCardClause & Required<Pick<JamlStandardCardClause, "standardCards">> | JamlErraticRankClause & Required<Pick<JamlErraticRankClause, "erraticRank">> | JamlErraticRankClause & Required<Pick<JamlErraticRankClause, "erraticRanks">> | JamlErraticSuitClause & Required<Pick<JamlErraticSuitClause, "erraticSuit">> | JamlErraticSuitClause & Required<Pick<JamlErraticSuitClause, "erraticSuits">> | JamlVoucherClause & Required<Pick<JamlVoucherClause, "voucher">> | JamlVoucherClause & Required<Pick<JamlVoucherClause, "vouchers">> | JamlTagClause & Required<Pick<JamlTagClause, "tag">> | JamlTagClause & Required<Pick<JamlTagClause, "tags">> | JamlSmallBlindTagClause & Required<Pick<JamlSmallBlindTagClause, "smallBlindTag">> | JamlBigBlindTagClause & Required<Pick<JamlBigBlindTagClause, "bigBlindTag">> | JamlBossClause & Required<Pick<JamlBossClause, "boss">> | JamlBossClause & Required<Pick<JamlBossClause, "bosses">> | JamlBoosterPackClause & Required<Pick<JamlBoosterPackClause, "boosterPack">> | JamlBoosterPackClause & Required<Pick<JamlBoosterPackClause, "boosterPacks">> | JamlPokerHandClause & Required<Pick<JamlPokerHandClause, "pokerHand">> | JamlPokerHandClause & Required<Pick<JamlPokerHandClause, "pokerHands">> | JamlStartingDrawClause & Required<Pick<JamlStartingDrawClause, "startingDraw">> | JamlLuckyMoneyClause & Required<Pick<JamlLuckyMoneyClause, "luckyMoney">> | JamlLuckyMultClause & Required<Pick<JamlLuckyMultClause, "luckyMult">> | JamlMisprintMultClause & Required<Pick<JamlMisprintMultClause, "misprintMult">> | JamlWheelOfFortuneClause & Required<Pick<JamlWheelOfFortuneClause, "wheelOfFortune">> | JamlWheelStaysFlippedClause & Required<Pick<JamlWheelStaysFlippedClause, "wheelStaysFlipped">> | JamlGlassDestroyClause & Required<Pick<JamlGlassDestroyClause, "glassDestroy">> | JamlCavendishExtinctClause & Required<Pick<JamlCavendishExtinctClause, "cavendishExtinct">> | JamlGrosMichelExtinctClause & Required<Pick<JamlGrosMichelExtinctClause, "grosMichelExtinct">> | JamlSpaceLevelupClause & Required<Pick<JamlSpaceLevelupClause, "spaceLevelup">> | JamlBusinessPayoutClause & Required<Pick<JamlBusinessPayoutClause, "businessPayout">> | JamlParkingPayoutClause & Required<Pick<JamlParkingPayoutClause, "parkingPayout">> | JamlBloodstoneTriggerClause & Required<Pick<JamlBloodstoneTriggerClause, "bloodstoneTrigger">> | JamlAndClause & Required<Pick<JamlAndClause, "and">> | JamlOrClause & Required<Pick<JamlOrClause, "or">> | JamlLegendarySoulOrderClause & Required<Pick<JamlLegendarySoulOrderClause, "soulOrder">> | JamlLegendarySoulOrderClause & Required<Pick<JamlLegendarySoulOrderClause, "soulOrders">>;
